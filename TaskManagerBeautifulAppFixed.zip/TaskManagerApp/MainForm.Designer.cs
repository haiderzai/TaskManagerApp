
namespace TaskManagerApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridViewPersons;
        private System.Windows.Forms.DataGridView dataGridViewTasks;
        private System.Windows.Forms.TextBox textBoxPersonName;
        private System.Windows.Forms.DateTimePicker dateTimePickerBirthday;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Button buttonAddPerson;
        private System.Windows.Forms.Button buttonUpdatePerson;
        private System.Windows.Forms.Button buttonDeletePerson;
        private System.Windows.Forms.TextBox textBoxTaskName;
        private System.Windows.Forms.TextBox textBoxDescription;
        private System.Windows.Forms.DateTimePicker dateTimePickerStart;
        private System.Windows.Forms.DateTimePicker dateTimePickerDue;
        private System.Windows.Forms.ComboBox comboBoxResponsible;
        private System.Windows.Forms.ComboBox comboBoxStatus;
        private System.Windows.Forms.Button buttonAddTask;
        private System.Windows.Forms.Button buttonUpdateTask;
        private System.Windows.Forms.Button buttonDeleteTask;
        private System.Windows.Forms.ComboBox comboBoxFilterStatus;
        private System.Windows.Forms.Button buttonFilter;
        private System.Windows.Forms.Button buttonSortByName;
        private System.Windows.Forms.Button buttonSortByDueDate;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonSearchTask;
        private System.Windows.Forms.Label labelTaskProgress;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dataGridViewPersons = new System.Windows.Forms.DataGridView();
            this.dataGridViewTasks = new System.Windows.Forms.DataGridView();
            this.textBoxPersonName = new System.Windows.Forms.TextBox();
            this.dateTimePickerBirthday = new System.Windows.Forms.DateTimePicker();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.buttonAddPerson = new System.Windows.Forms.Button();
            this.buttonUpdatePerson = new System.Windows.Forms.Button();
            this.buttonDeletePerson = new System.Windows.Forms.Button();
            this.textBoxTaskName = new System.Windows.Forms.TextBox();
            this.textBoxDescription = new System.Windows.Forms.TextBox();
            this.dateTimePickerStart = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerDue = new System.Windows.Forms.DateTimePicker();
            this.comboBoxResponsible = new System.Windows.Forms.ComboBox();
            this.comboBoxStatus = new System.Windows.Forms.ComboBox();
            this.buttonAddTask = new System.Windows.Forms.Button();
            this.buttonUpdateTask = new System.Windows.Forms.Button();
            this.buttonDeleteTask = new System.Windows.Forms.Button();
            this.comboBoxFilterStatus = new System.Windows.Forms.ComboBox();
            this.buttonFilter = new System.Windows.Forms.Button();
            this.buttonSortByName = new System.Windows.Forms.Button();
            this.buttonSortByDueDate = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.buttonSearchTask = new System.Windows.Forms.Button();
            this.labelTaskProgress = new System.Windows.Forms.Label();

            this.SuspendLayout();

            // Task Data Grid
            this.dataGridViewTasks.Location = new System.Drawing.Point(400, 20);
            this.dataGridViewTasks.Size = new System.Drawing.Size(600, 250);
            this.dataGridViewTasks.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            // Person Data Grid
            this.dataGridViewPersons.Location = new System.Drawing.Point(20, 20);
            this.dataGridViewPersons.Size = new System.Drawing.Size(360, 150);

            // Person Inputs
            this.textBoxPersonName.Location = new System.Drawing.Point(20, 180);
            this.dateTimePickerBirthday.Location = new System.Drawing.Point(20, 210);
            this.textBoxEmail.Location = new System.Drawing.Point(20, 240);
            this.buttonAddPerson.Location = new System.Drawing.Point(20, 270);
            this.buttonAddPerson.Text = "Add Person";
            this.buttonUpdatePerson.Location = new System.Drawing.Point(120, 270);
            this.buttonUpdatePerson.Text = "Update Person";
            this.buttonDeletePerson.Location = new System.Drawing.Point(220, 270);
            this.buttonDeletePerson.Text = "Delete Person";

            this.buttonAddPerson.Click += new System.EventHandler(this.buttonAddPerson_Click);
            this.buttonUpdatePerson.Click += new System.EventHandler(this.buttonUpdatePerson_Click);
            this.buttonDeletePerson.Click += new System.EventHandler(this.buttonDeletePerson_Click);

            // Task Inputs
            this.textBoxTaskName.Location = new System.Drawing.Point(400, 280);
            this.textBoxDescription.Location = new System.Drawing.Point(400, 310);
            this.dateTimePickerStart.Location = new System.Drawing.Point(400, 340);
            this.dateTimePickerDue.Location = new System.Drawing.Point(400, 370);
            this.comboBoxResponsible.Location = new System.Drawing.Point(400, 400);
            this.comboBoxStatus.Location = new System.Drawing.Point(400, 430);

            this.buttonAddTask.Location = new System.Drawing.Point(400, 460);
            this.buttonAddTask.Text = "Add Task";
            this.buttonUpdateTask.Location = new System.Drawing.Point(500, 460);
            this.buttonUpdateTask.Text = "Update Task";
            this.buttonDeleteTask.Location = new System.Drawing.Point(600, 460);
            this.buttonDeleteTask.Text = "Delete Task";

            this.buttonAddTask.Click += new System.EventHandler(this.buttonAddTask_Click);
            this.buttonUpdateTask.Click += new System.EventHandler(this.buttonUpdateTask_Click);
            this.buttonDeleteTask.Click += new System.EventHandler(this.buttonDeleteTask_Click);

            // Filter and Sort
            this.comboBoxFilterStatus.Location = new System.Drawing.Point(20, 320);
            this.buttonFilter.Location = new System.Drawing.Point(180, 320);
            this.buttonFilter.Text = "Filter";

            this.buttonSortByName.Location = new System.Drawing.Point(20, 360);
            this.buttonSortByName.Text = "Sort by Name";
            this.buttonSortByDueDate.Location = new System.Drawing.Point(180, 360);
            this.buttonSortByDueDate.Text = "Sort by Due Date";

            this.buttonFilter.Click += new System.EventHandler(this.buttonFilter_Click);
            this.buttonSortByName.Click += new System.EventHandler(this.buttonSortByName_Click);
            this.buttonSortByDueDate.Click += new System.EventHandler(this.buttonSortByDueDate_Click);

            // Search
            this.textBoxSearch.Location = new System.Drawing.Point(20, 400);
            this.buttonSearchTask.Location = new System.Drawing.Point(180, 400);
            this.buttonSearchTask.Text = "Search Task";
            this.buttonSearchTask.Click += new System.EventHandler(this.buttonSearchTask_Click);

            // Label for status
            this.labelTaskProgress.Location = new System.Drawing.Point(20, 440);
            this.labelTaskProgress.Size = new System.Drawing.Size(300, 20);
            this.labelTaskProgress.Text = "Task Manager - Progress Overview";

            // Add controls
            this.Controls.Add(this.dataGridViewPersons);
            this.Controls.Add(this.dataGridViewTasks);
            this.Controls.Add(this.textBoxPersonName);
            this.Controls.Add(this.dateTimePickerBirthday);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.buttonAddPerson);
            this.Controls.Add(this.buttonUpdatePerson);
            this.Controls.Add(this.buttonDeletePerson);
            this.Controls.Add(this.textBoxTaskName);
            this.Controls.Add(this.textBoxDescription);
            this.Controls.Add(this.dateTimePickerStart);
            this.Controls.Add(this.dateTimePickerDue);
            this.Controls.Add(this.comboBoxResponsible);
            this.Controls.Add(this.comboBoxStatus);
            this.Controls.Add(this.buttonAddTask);
            this.Controls.Add(this.buttonUpdateTask);
            this.Controls.Add(this.buttonDeleteTask);
            this.Controls.Add(this.comboBoxFilterStatus);
            this.Controls.Add(this.buttonFilter);
            this.Controls.Add(this.buttonSortByName);
            this.Controls.Add(this.buttonSortByDueDate);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.buttonSearchTask);
            this.Controls.Add(this.labelTaskProgress);

            this.Text = "Task Manager (Beautiful UI)";
            this.ClientSize = new System.Drawing.Size(1050, 520);
            this.ResumeLayout(false);
        }
    }
}
